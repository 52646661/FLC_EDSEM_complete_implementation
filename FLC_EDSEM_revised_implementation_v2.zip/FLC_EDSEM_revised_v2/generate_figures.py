from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
source = ROOT / "results/demo_plot_source_data.csv"
if not source.exists():
    raise SystemExit("Run `python run_demo.py` first.")
df = pd.read_csv(source)
figdir = ROOT / "figures"
figdir.mkdir(exist_ok=True)

series = [
    ("grid_import_kw", "Grid Import Power (kW)", "demo_grid_import.png"),
    ("pv_generation_kw", "PV Generation (kW)", "demo_pv_generation.png"),
    ("battery_power_kw", "Battery Power (kW)", "demo_battery_power.png"),
    ("soc", "Battery State of Charge", "demo_battery_soc.png"),
    ("grid_cost", "Hourly Grid Cost", "demo_hourly_grid_cost.png"),
]
labels = {
    "complete": "FLC-EDSEM",
    "without_gps": "Without GPS",
    "without_rem": "Without REM",
    "without_fls": "Without FLS",
    "baseline": "Baseline",
}
for column, ylabel, filename in series:
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for key, label in labels.items():
        subset = df[df.configuration == key]
        ax.plot(subset.hour, subset[column], marker="o", markersize=3, label=label)
    ax.set_xlabel("Hour of Day")
    ax.set_ylabel(ylabel)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(figdir / filename, dpi=300)
    plt.close(fig)
print(f"Figures saved to {figdir}. They are derived from the demonstration simulation.")
