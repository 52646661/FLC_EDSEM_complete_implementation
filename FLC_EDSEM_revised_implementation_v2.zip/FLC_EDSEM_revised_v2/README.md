# FLC-EDSEM reproducibility package — revised v2

## Scope and important reproducibility note

This package corrects the earlier archive's inconsistent terminology and provides one executable, documented **reference simulation** for the three implemented energy-management functions:

1. Grid Power Selection (GPS)
2. Renewable Energy Management (REM)
3. Fuzzy Load Switching (FLS)

The FLC has four inputs: commercial load demand, PV power availability, battery state of charge (SoC), and electricity tariff. It produces two outputs: Battery Power-Control Command (BPC: charge/idle/discharge) and Load Connection-Control Command (LCC: connect/delay/disconnect).

**No independent day-ahead, intraday, or real-time load-forecasting module is implemented.** The Energy Efficiency Dataset contains building attributes and heating/cooling targets; regression-based cooling-load estimation (Y2) is a separate task and is not used as a temporal forecast by this controller.

### Critical limitation

The earlier manuscript materials supplied for this revision do not contain the original PV time series, tariff series, battery specification, complete fuzzy membership boundaries/rule matrix, definitive benchmark implementations, original run-level outputs, or authoritative formula definitions for all five reported indices. Consequently, this archive does **not** claim to reproduce the manuscript's reported values (98.5%, 99.5%, 97.9%, 95.6%, 11.2%) or the earlier ablation values.

The included 24-hour profile is an explicitly labelled **illustrative demonstration scenario**. Its 30-run output is generated from this scenario and must not be represented as the original manuscript's experimental data. Replace the illustrative inputs and controller configuration with the authors' original recorded values before claiming exact reproduction.

## Repository structure

- `src/controller.py` — Mamdani-style fuzzy decision controller; explicit four inputs and two outputs.
- `src/simulation.py` — PV/battery/grid/load energy-balance simulation and module ablations.
- `src/statistics.py` — mean, sample SD, t-based 95% CI, and paired t-test utilities.
- `src/dataset.py` — validates the public Energy Efficiency Dataset schema (768 rows, X1–X8, Y1, Y2).
- `config/model_config.json` — illustrative operating parameters and seed list.
- `config/metric_definitions.json` — transparent definitions for physical energy-balance outputs; manuscript-specific indices requiring author confirmation are not fabricated.
- `run_demo.py` — executes 30 illustrative runs and writes run-level/hourly outputs.
- `generate_figures.py` — generates demonstration energy-balance plots from the simulation CSV output, not the manuscript Figures 5–9.
- `tests/` — basic controller and energy-balance checks.

## Installation

Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Execute the illustrative simulation

```bash
python run_demo.py
python generate_figures.py
python -m unittest discover -s tests
```

Outputs are written to `results/` and `figures/`:
- `run_level_results.csv` — one row per seed and configuration.
- `hourly_results.csv` — hourly energy-balance values for every run.
- `summary_statistics.csv` — mean, sample SD, 95% t CI.
- `paired_tests.csv` — paired t-tests against the no-control baseline.
- `demo_plot_source_data.csv` — hourly demonstration profile data used by the five generated demonstration plots. These are not the manuscript Figures 5–9 source data.

## Statistical procedure

For each metric, the package computes the mean and sample SD over the 30 run-level observations. The two-sided 95% confidence interval is `mean ± t(0.975, n−1) × SD / sqrt(n)`. Paired tests compare matching seeds under FLC-EDSEM and the no-control baseline. The generated p-values apply only to the illustrative demonstration scenario.

## Dataset

The Energy Efficiency Dataset is available from Kaggle:
https://www.kaggle.com/datasets/elikplim/eergy-efficiency-dataset

If using the dataset validation utility, save the downloaded file as `data/energy_efficiency.csv`. Expected columns are `X1,X2,X3,X4,X5,X6,X7,X8,Y1,Y2` and expected row count is 768. The dataset is not bundled because it is externally hosted.

## Before using this archive as the manuscript's definitive supplement

The authors must replace the illustrative operating profile and provisional controller settings with the original study configuration, add the actual MCDA/RTPDRP/ISDSDSM/DLO comparator implementations, confirm the exact mathematical definitions of DRR/PAR/EER/ECPR/ECI, and regenerate all reported values and manuscript Figures 5–9 from the saved original inputs. Those comparator implementations and original manuscript source data were not supplied and are not invented in this archive. Do not copy illustrative demonstration results into the manuscript.
