"""Schema validation for the externally hosted Energy Efficiency Dataset."""
import pandas as pd

EXPECTED = ["X1", "X2", "X3", "X4", "X5", "X6", "X7", "X8", "Y1", "Y2"]

def load_energy_efficiency_dataset(path="data/energy_efficiency.csv"):
    df = pd.read_csv(path)
    df.columns = [str(c).replace("\ufeff", "").strip() for c in df.columns]
    missing = [c for c in EXPECTED if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if len(df) != 768:
        raise ValueError(f"Expected 768 samples; found {len(df)}")
    return df[EXPECTED].copy()
