"""Dependency-light Mamdani fuzzy decision controller.

Four normalized inputs: demand, PV availability, battery SoC, tariff.
Two outputs: battery power command (BPC) and load connection command (LCC).
Membership boundaries and rules are the explicit reference configuration in
this archive; replace them if the original manuscript settings differ.
"""
import numpy as np


def trimf(x, abc):
    a, b, c = map(float, abc)
    x = np.asarray(x, dtype=float)
    y = np.zeros_like(x)
    if b > a:
        m = (x >= a) & (x <= b)
        y[m] = (x[m] - a) / (b - a)
    else:
        y[x == a] = 1.0
    if c > b:
        m = (x >= b) & (x <= c)
        y[m] = np.maximum(y[m], (c - x[m]) / (c - b))
    else:
        y[x == c] = 1.0
    y[x == b] = 1.0
    return np.clip(y, 0.0, 1.0)


class FLCEDSEM:
    def __init__(self):
        self.universe = np.linspace(0.0, 1.0, 1001)
        self.sets = {
            "low": lambda x: max(0.0, min(1.0, (0.5 - x) / 0.5)) if x > 0 else 1.0,
            "medium": lambda x: max(0.0, min((x / 0.5) if x <= 0.5 else ((1.0 - x) / 0.5), 1.0)),
            "high": lambda x: max(0.0, min(1.0, (x - 0.5) / 0.5)) if x < 1 else 1.0,
        }
        self.output_sets = {
            "discharge": trimf(self.universe, [0.0, 0.0, 0.5]),
            "idle": trimf(self.universe, [0.0, 0.5, 1.0]),
            "charge": trimf(self.universe, [0.5, 1.0, 1.0]),
            "disconnect": trimf(self.universe, [0.0, 0.0, 0.5]),
            "delay": trimf(self.universe, [0.0, 0.5, 1.0]),
            "connect": trimf(self.universe, [0.5, 1.0, 1.0]),
        }

    def _mu(self, x):
        x = float(np.clip(x, 0.0, 1.0))
        low = max(0.0, (0.5 - x) / 0.5)
        med = max(0.0, min(x / 0.5, (1.0 - x) / 0.5))
        high = max(0.0, (x - 0.5) / 0.5)
        if x == 0.0: low = 1.0
        if x == 1.0: high = 1.0
        return {"low": low, "medium": med, "high": high}

    def _infer(self, rules):
        aggregate = np.zeros_like(self.universe)
        for strength, label in rules:
            aggregate = np.maximum(aggregate, np.minimum(strength, self.output_sets[label]))
        area = np.trapz(aggregate, self.universe)
        if area <= 1e-12:
            return 0.5
        return float(np.trapz(self.universe * aggregate, self.universe) / area)

    def predict(self, demand, pv, soc, tariff):
        d, p, s, t = [self._mu(v) for v in (demand, pv, soc, tariff)]
        battery_rules = [
            (min(p["high"], s["low"]), "charge"),
            (min(p["high"], s["medium"]), "charge"),
            (min(p["high"], s["high"]), "idle"),
            (min(p["low"], d["high"], s["high"]), "discharge"),
            (min(p["medium"], d["high"], s["high"]), "discharge"),
            (min(p["low"], d["high"], s["low"]), "idle"),
            (min(p["medium"], d["low"], s["low"]), "charge"),
            (min(p["low"], s["medium"], t["high"]), "discharge"),
            (min(p["low"], s["low"]), "idle"),
        ]
        load_rules = [
            (min(d["low"], p["high"]), "connect"),
            (min(d["medium"], p["high"]), "connect"),
            (min(d["high"], p["low"], t["high"]), "disconnect"),
            (min(d["high"], p["low"], t["medium"]), "delay"),
            (min(d["medium"], p["low"], t["high"]), "delay"),
            (min(d["low"], t["low"]), "connect"),
            (min(d["high"], p["medium"]), "delay"),
            (min(d["medium"], p["medium"]), "connect"),
        ]
        bpc_value = self._infer(battery_rules)
        lcc_value = self._infer(load_rules)
        bpc = "discharge" if bpc_value < 0.33 else ("idle" if bpc_value < 0.67 else "charge")
        lcc = "disconnect" if lcc_value < 0.33 else ("delay" if lcc_value < 0.67 else "connect")
        return bpc, lcc, bpc_value, lcc_value
