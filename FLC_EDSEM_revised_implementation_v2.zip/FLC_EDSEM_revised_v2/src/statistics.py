"""Descriptive statistics and paired comparisons for run-level results."""
import numpy as np
import pandas as pd
from scipy import stats


def summarize_runs(run_df, metric_columns, group_column="configuration"):
    rows = []
    for group, subset in run_df.groupby(group_column):
        for metric in metric_columns:
            x = subset[metric].dropna().to_numpy(dtype=float)
            n = len(x)
            mean = float(np.mean(x))
            sd = float(np.std(x, ddof=1)) if n > 1 else float("nan")
            margin = float(stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else float("nan")
            rows.append({
                group_column: group, "metric": metric, "n": n, "mean": mean,
                "sample_sd": sd, "ci95_lower": mean - margin, "ci95_upper": mean + margin
            })
    return pd.DataFrame(rows)


def paired_tests(run_df, metric_columns, treatment="complete", baseline="baseline"):
    rows = []
    wide = run_df.pivot(index="seed", columns="configuration", values=metric_columns)
    for metric in metric_columns:
        a = wide[metric][treatment].dropna()
        b = wide[metric][baseline].dropna()
        common = a.index.intersection(b.index)
        a, b = a.loc[common], b.loc[common]
        test = stats.ttest_rel(a, b, alternative="two-sided")
        rows.append({
            "metric": metric, "treatment": treatment, "baseline": baseline,
            "n_pairs": len(common), "mean_difference_treatment_minus_baseline": float((a-b).mean()),
            "t_statistic": float(test.statistic), "p_value_two_sided": float(test.pvalue)
        })
    return pd.DataFrame(rows)
