"""Illustrative hourly hybrid PV-battery-grid simulation."""
import numpy as np
import pandas as pd
from .controller import FLCEDSEM


def illustrative_profiles(seed, cfg):
    rng = np.random.default_rng(seed)
    h = np.arange(int(cfg["hours"]))
    # Demonstration-only commercial demand and solar generation profiles.
    shape = 0.62 + 0.20 * np.sin((h - 8) * np.pi / 12) + 0.12 * np.sin((h - 15) * np.pi / 6)
    shape = np.clip(shape, 0.35, 1.15)
    base = float(cfg["base_load_kw"]) * shape
    flexible = np.full_like(base, float(cfg["flexible_load_kw"]), dtype=float)
    demand_noise = rng.normal(1.0, 0.035, len(h))
    load = np.maximum(0.1, (base + flexible) * demand_noise)
    solar_shape = np.maximum(0.0, np.sin(np.pi * (h - 6) / 12))
    pv = float(cfg["pv_peak_kw"]) * solar_shape * rng.normal(1.0, 0.04, len(h))
    pv = np.maximum(0.0, pv)
    tariff = np.full(len(h), float(cfg["offpeak_tariff"]))
    for peak_hour in cfg["tariff_peak_hours"]:
        tariff[int(peak_hour)] = float(cfg["peak_tariff"])
    return h, load, pv, tariff


def simulate(seed, cfg, ablation="complete"):
    if ablation not in {"complete", "without_gps", "without_rem", "without_fls", "baseline"}:
        raise ValueError(f"Unknown configuration: {ablation}")
    h, demand, pv, tariff = illustrative_profiles(seed, cfg)
    controller = FLCEDSEM()
    capacity = float(cfg["battery_capacity_kwh"])
    max_power = float(cfg["battery_max_power_kw"])
    min_soc, max_soc = float(cfg["min_soc"]), float(cfg["max_soc"])
    soc = float(cfg["initial_soc"])
    rows = []

    for i, hour in enumerate(h):
        raw_load = float(demand[i])
        available_pv = float(pv[i])
        price = float(tariff[i])
        load = raw_load
        bpc, lcc = "idle", "connect"

        if ablation != "baseline":
            bpc, lcc, _, _ = controller.predict(
                raw_load / max(demand.max(), 1e-9),
                available_pv / max(float(cfg["pv_peak_kw"]), 1e-9),
                soc,
                price / max(float(cfg["peak_tariff"]), 1e-9),
            )

        if ablation == "without_fls":
            lcc = "connect"
        if ablation == "without_rem":
            available_pv = 0.0
        if ablation == "without_gps":
            # No explicit grid-selection logic: grid supplies the residual load.
            bpc = "idle"

        if lcc in {"delay", "disconnect"}:
            flexible_served = 0.0
        else:
            flexible_served = min(float(cfg["flexible_load_kw"]), raw_load)
        essential = max(0.0, raw_load - float(cfg["flexible_load_kw"]))
        served_load = essential + flexible_served

        pv_to_load = min(available_pv, served_load)
        pv_surplus = max(0.0, available_pv - pv_to_load)
        battery_power = 0.0  # positive = charge; negative = discharge
        eta_c = float(cfg["charge_efficiency"])
        eta_d = float(cfg["discharge_efficiency"])

        if bpc == "charge" and pv_surplus > 0 and ablation != "without_rem":
            charge_room_kw = max(0.0, (max_soc - soc) * capacity / eta_c)
            battery_power = min(max_power, pv_surplus, charge_room_kw)
        elif bpc == "discharge" and soc > min_soc:
            discharge_room_kw = max(0.0, (soc - min_soc) * capacity * eta_d)
            battery_power = -min(max_power, max(0.0, served_load - pv_to_load), discharge_room_kw)

        if battery_power > 0:
            soc = min(max_soc, soc + battery_power * eta_c / capacity)
        elif battery_power < 0:
            soc = max(min_soc, soc + battery_power / (eta_d * capacity))

        pv_to_battery = max(0.0, battery_power)
        battery_to_load = max(0.0, -battery_power)
        grid_import = max(0.0, served_load - pv_to_load - battery_to_load)
        pv_curtailed = max(0.0, pv_surplus - pv_to_battery)
        cost = grid_import * price
        rows.append({
            "seed": seed, "configuration": ablation, "hour": int(hour),
            "commercial_demand_kw": raw_load, "served_load_kw": served_load,
            "pv_generation_kw": available_pv, "pv_to_load_kw": pv_to_load,
            "pv_to_battery_kw": pv_to_battery, "pv_curtailed_kw": pv_curtailed,
            "battery_power_kw": battery_power, "grid_import_kw": grid_import,
            "soc": soc, "tariff_per_kwh": price, "grid_cost": cost,
            "BPC": bpc, "LCC": lcc,
        })
    hourly = pd.DataFrame(rows)
    summary = {
        "seed": seed, "configuration": ablation,
        "grid_energy_kwh": hourly["grid_import_kw"].sum(),
        "pv_generated_kwh": hourly["pv_generation_kw"].sum(),
        "pv_used_locally_kwh": (hourly["pv_to_load_kw"] + hourly["pv_to_battery_kw"]).sum(),
        "pv_self_consumption_ratio_percent": (
            100.0 * (hourly["pv_to_load_kw"] + hourly["pv_to_battery_kw"]).sum()
            / max(hourly["pv_generation_kw"].sum(), 1e-9)
        ),
        "peak_grid_import_kw": hourly["grid_import_kw"].max(),
        "unserved_or_shifted_flexible_kwh": (
            hourly["commercial_demand_kw"] - hourly["served_load_kw"]
        ).sum(),
        "operating_cost": hourly["grid_cost"].sum(),
        "final_soc": hourly["soc"].iloc[-1],
    }
    return hourly, summary
