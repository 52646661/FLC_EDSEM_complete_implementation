from pathlib import Path
import json
import pandas as pd
from src.simulation import simulate
from src.statistics import summarize_runs, paired_tests

ROOT = Path(__file__).resolve().parent
cfg = json.loads((ROOT / "config/model_config.json").read_text())
out = ROOT / "results"
out.mkdir(exist_ok=True)

configs = ["complete", "without_gps", "without_rem", "without_fls", "baseline"]
hourly_frames, summaries = [], []
for seed in cfg["random_seeds"]:
    for configuration in configs:
        hourly, summary = simulate(seed, cfg, configuration)
        hourly_frames.append(hourly)
        summaries.append(summary)

hourly_df = pd.concat(hourly_frames, ignore_index=True)
run_df = pd.DataFrame(summaries)
hourly_df.to_csv(out / "hourly_results.csv", index=False)
run_df.to_csv(out / "run_level_results.csv", index=False)

metrics = [
    "grid_energy_kwh", "pv_generated_kwh", "pv_used_locally_kwh",
    "pv_self_consumption_ratio_percent", "peak_grid_import_kw",
    "unserved_or_shifted_flexible_kwh", "operating_cost", "final_soc"
]
summarize_runs(run_df, metrics).to_csv(out / "summary_statistics.csv", index=False)
paired_tests(run_df, metrics).to_csv(out / "paired_tests.csv", index=False)

# Long-form source data for plots, computed from run-level simulation outputs.
plot_df = hourly_df.groupby(["configuration", "hour"], as_index=False).mean(numeric_only=True)
plot_df.to_csv(out / "demo_plot_source_data.csv", index=False)
print(f"Finished illustrative 30-seed simulation. Outputs: {out}")
print("WARNING: these are demonstration outputs, not the manuscript's original experimental results.")
