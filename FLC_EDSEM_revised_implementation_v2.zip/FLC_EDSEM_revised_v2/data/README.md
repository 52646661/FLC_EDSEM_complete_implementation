The Energy Efficiency Dataset is externally hosted at:
https://www.kaggle.com/datasets/elikplim/eergy-efficiency-dataset

Download the CSV and save it as `data/energy_efficiency.csv` if dataset validation is required. Expected schema: X1–X8, Y1, Y2; expected row count: 768. No original study raw PV, tariff, battery, or commercial-load time series were present in the materials supplied for this revision, so none are fabricated or included here.
