import json
import unittest
from pathlib import Path
from src.controller import FLCEDSEM
from src.simulation import simulate

CFG = json.loads((Path(__file__).resolve().parents[1] / "config/model_config.json").read_text())

class TestFLCEDSEM(unittest.TestCase):
    def test_controller_outputs(self):
        result = FLCEDSEM().predict(0.7, 0.4, 0.6, 0.8)
        self.assertIn(result[0], {"charge", "idle", "discharge"})
        self.assertIn(result[1], {"connect", "delay", "disconnect"})

    def test_energy_balance_nonnegative_grid(self):
        hourly, summary = simulate(1, CFG, "complete")
        self.assertTrue((hourly.grid_import_kw >= 0).all())
        self.assertTrue(hourly.soc.between(CFG["min_soc"], CFG["max_soc"]).all())
        self.assertGreaterEqual(summary["grid_energy_kwh"], 0)

if __name__ == "__main__":
    unittest.main()
